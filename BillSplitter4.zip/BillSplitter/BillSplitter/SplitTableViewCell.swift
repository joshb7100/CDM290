//
//  SplitTableViewCell.swift
//  BillSplitter
//
//  Created by Josh T. Barrett on 4/3/17.
//  Copyright © 2017 Josh Barrett. All rights reserved.
//

import UIKit

class SplitTableViewCell: UITableViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
